<?php



if(isset($_FILES['spreadsheet']['tmp_name'])){
	require("PHPExcel/Classes/PHPExcel.php");
	require_once "PHPExcel/Classes/PHPExcel/IOFactory.php";
	$inputFile = $_FILES['spreadsheet']['tmp_name'];
	$path="Book1.xlsx";
	$fileObj=PHPExcel_IOFactory::load($inputFile);
	$sheetObj=$fileObj->getActiveSheet();
	$startFrom=1;
	$limit=null;

	foreach ($sheetObj->getRowIterator($startFrom,$limit) as $row) {
		$demo_query="";
		foreach ($row->getCellIterator() as $cell) {
			$value=$cell->getCalculatedValue();
			$demo_query.=$value.",";

		}
		echo $demo_query."<br>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="POST" enctype="multipart/form-data">
	<input type="file" name="spreadsheet"  accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
	<input type="submit">

</form>
</body>
</html>

